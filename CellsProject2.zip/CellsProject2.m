
cellImage = imread('C:/Users/ygt/Desktop/cels/images.jpeg');


if size(cellImage,3)==3
    cellImageGray = rgb2gray(cellImage);
else
    cellImageGray = cellImage;
end


binaryImage = imbinarize(cellImageGray);
binaryImage = imcomplement(binaryImage);
binaryImage = bwareaopen(binaryImage,50);


[labeledImage, regionCount] = bwlabel(binaryImage);



mask8       = im2uint8(~binaryImage);         
outputMask  = cat(3, mask8, mask8, mask8);    


figure('Color','k');


subplot(1,2,1);
imshow(cellImageGray);
title('INPUT IMAGE','Color','w','FontSize',14);
axis off;


subplot(1,2,2);
imshow(outputMask);
title('OUTPUT IMAGE','Color','w','FontSize',14);
hold on;
axis off;


for i = 1:regionCount
    mask_i = (labeledImage==i);
    s = regionprops(mask_i,'BoundingBox','Centroid');
    
    
    filled = imfill(mask_i,'holes');
    holes  = filled & ~mask_i;
    holes  = imclearborder(holes);
    [~, hc] = bwlabel(holes);

    if hc == 1
        boxColor = 'r'; textLabel = '1 hole';
    elseif hc == 2
        boxColor = 'b'; textLabel = '2 holes';
    elseif hc > 2
        boxColor = 'g'; textLabel = 'cluster';
    else
        boxColor = 'y'; textLabel = 'unknown';
    end

    rectangle('Position', s.BoundingBox, ...
              'EdgeColor', boxColor, 'LineWidth', 2);
    text(s.Centroid(1), s.Centroid(2), textLabel, ...
        'Color','w','FontSize',8,'FontWeight','bold', ...
        'HorizontalAlignment','center');
end


annotation('textbox',[0.53 0.18 0.45 0.05], ...
    'String','Red – indicates that cell has one big hole', ...
    'Color','r','EdgeColor','none','FontSize',10,'FontWeight','bold');
annotation('textbox',[0.53 0.13 0.45 0.05], ...
    'String','Blue – indicates that cell has two big holes', ...
    'Color','b','EdgeColor','none','FontSize',10,'FontWeight','bold');
annotation('textbox',[0.53 0.08 0.45 0.05], ...
    'String','Green – indicates that two cells with holes', ...
    'Color','g','EdgeColor','none','FontSize',10,'FontWeight','bold');
